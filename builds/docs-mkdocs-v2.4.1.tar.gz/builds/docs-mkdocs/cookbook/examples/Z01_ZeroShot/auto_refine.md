---
title: 'Auto-Refine The Prompt'
docname: 'auto_refine'
id: 'c595'
tags:
  - 'zero-shot'
  - 'prompt-refinement'
  - 'editing'
---
## Overview

How do we remove irrelevant information from the prompt?

The S2A (System 2 Attention) technique auto-refines a prompt by asking the model to
rewrite the prompt to include only relevant information.

We implement this in two steps:

 1. Ask the model to rewrite the prompt
 2. Pass the rewritten prompt back to the model

## Example

```php
<?php
require 'examples/boot.php';

use Cognesy\Instructor\Extras\Scalar\Scalar;
use Cognesy\Instructor\StructuredOutput;
use Cognesy\Schema\Attributes\Description;

class RewrittenTask {
    #[Description("All numerical facts and operations from the text that are needed to answer the question — do not omit any numbers or math steps")]
    public string $relevantContext;
    #[Description("The exact question from the user")]
    public string $userQuery;
}

class RefineAndSolve {
    private string $prompt = <<<PROMPT
        Given the following text by a user, extract the part
        that is actually relevant to their question. Include
        the actual question or query that the user is asking.
        
        Text by user:
        {query}
        PROMPT;

    public function __invoke(string $problem) : int {
        $rewrittenPrompt = $this->rewritePrompt($problem);
        return StructuredOutput::using('openai')
            ->with(
                messages: "{$rewrittenPrompt->relevantContext}\nQuestion: {$rewrittenPrompt->userQuery}",
                responseModel: Scalar::integer('answer'),
            )
            ->getInt();
    }

    private function rewritePrompt(string $query) : RewrittenTask {
        return StructuredOutput::using('openai')->with(
            messages: str_replace('{query}', $query, $this->prompt),
            responseModel: RewrittenTask::class,
            model: 'gpt-4o-mini',
        )->get();
    }
}

$answer = (new RefineAndSolve)(problem: <<<PROBLEM
    Mary has 3 times as much candy as Megan.
    Mary then adds 10 more pieces of candy to her collection.
    Max is 5 years older than Mary.
    If Megan has 5 pieces of candy, how many does Mary have in total?
    PROBLEM,
);

echo $answer . "\n";

assert(is_int($answer));
assert($answer >= 15, "Expected at least 15 (3*5), full answer is 25 (3*5+10)");
?>
```

## References

 1. [System 2 Attention (is something you might need too)](https://arxiv.org/abs/2311.11829)



