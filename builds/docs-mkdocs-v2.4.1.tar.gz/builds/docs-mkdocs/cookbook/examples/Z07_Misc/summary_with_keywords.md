---
title: 'Summary with Keywords'
docname: 'summary_with_keywords'
id: '8ad6'
tags:
  - 'misc'
  - 'summarization'
  - 'keywords'
---
## Overview

This is an example of a simple summarization with keyword extraction.

## Example

```php
<?php
require 'examples/boot.php';

use Cognesy\Instructor\StructuredOutput;
use Cognesy\Instructor\StructuredOutputRuntime;
use Cognesy\Instructor\Validation\Traits\ValidationMixin;
use Cognesy\Instructor\Validation\ValidationResult;
use Cognesy\Polyglot\Inference\LLMProvider;
use Cognesy\Schema\Attributes\Description;

$report = <<<EOT
    [2021-09-01]
    Acme Insurance project to implement SalesTech CRM solution is currently
    in RED status due to delayed delivery of document production system, led
    by 3rd party vendor - Alfatech. Customer (Acme) is discussing the resolution
    with the vendor. Due to dependencies it will result in delay of the
    ecommerce track by 2 sprints. System integrator (SysCorp) are working
    to absorb some of the delay by deploying extra resources to speed up
    development when the doc production is done. Another issue is that the
    customer is not able to provide the test data for the ecommerce track.
    SysCorp notified it will impact stabilization schedule unless resolved by
    the end of the month. Steerco has been informed last week about the
    potential impact of the issues, but insists on maintaining release schedule
    due to marketing campaign already ongoing. Customer executives are asking
    us - SalesTech team - to confirm SysCorp's assessment of the situation.
    We're struggling with that due to communication issues - SysCorp team has
    not shown up on 2 recent calls. Lack of insight has been escalated to
    SysCorp's leadership team yesterday, but we've got no response yet. The
    previously reported Integration Proxy connectivity issue which was blocking
    policy track has been resolved on 2021-08-30 - the track is now GREEN.
    Production deployment plan has been finalized on Aug 15th and awaiting
    customer approval.
    EOT;

class Summary {
    use ValidationMixin;

    #[Description('Project summary, not longer than 3 sentences')]
    public string $summary = '';

    #[Description('Exactly 5 most relevant keywords extracted from the summary')]
    /** @var string[] */
    public array $keywords = [];

    public function validate() : ValidationResult
    {
        return match (true) {
            count($this->keywords) !== 5 => ValidationResult::fieldError(
                field: 'keywords',
                value: json_encode($this->keywords),
                message: 'Provide exactly 5 keywords.',
            ),
            $this->hasBlankKeywords() => ValidationResult::fieldError(
                field: 'keywords',
                value: json_encode($this->keywords),
                message: 'Each keyword must be a non-empty string.',
            ),
            default => ValidationResult::valid(),
        };
    }

    private function hasBlankKeywords() : bool
    {
        return count(array_filter(
            $this->keywords,
            fn(mixed $keyword): bool => !is_string($keyword) || trim($keyword) === '',
        )) > 0;
    }
}

$runtime = StructuredOutputRuntime::fromProvider(LLMProvider::using('openai'))
    ->withMaxRetries(2);

$summary = (new StructuredOutput($runtime))
    ->with(
        messages: $report,
        responseModel: Summary::class,
    )
    ->get();

dump($summary);

assert($summary instanceof Summary);
assert(!empty($summary->summary));
assert(count($summary->keywords) === 5, 'Expected 5 keywords, got: ' . count($summary->keywords));
foreach ($summary->keywords as $keyword) {
    assert(is_string($keyword));
    assert(!empty($keyword));
}
?>
```
