## We're looking for your help

We're looking for a bunch more examples.

If you have a tutorial or example you'd like to add, please open a pull request in `docs/hub` and we'll review it.

- [ ] Converting the cookbooks to the new format
- [ ] Validator examples
- [ ] Data extraction examples
- [ ] Streaming examples (Iterable and Partial)
- [ ] Batch Parsing examples
- [ ] Query Expansion examples
- [ ] Batch Data Processing examples
- [ ] Batch Data Processing examples with Cache

We're also looking for help to catch up with the features available in Instructor Hub for Python (see: https://github.com/jxnl/instructor/blob/main/docs/hub/index.md).

- [ ] Better viewer with pagination
- [ ] Examples database
- [ ] Pulling in the code to your own dir, so you can get started with the API



## How to contribute

We welcome contributions to the instructor hub, if you have a tutorial or example you'd like to add, please open a pull request in `docs/hub` and we'll review it.

1. The code must be in a single .php file.
2. Please include documentation in the file - check existing examples for the format.
3. Make sure that the code is tested.

```php
// @snippet-id=12e5
namespace Cognesy\Polyglot\Examples;

use Cognesy\Polyglot\Inference\Inference;

echo "Hello, world!\n";
```
